# Contributor Covenant Code of Conduct

We are committed to a welcoming, respectful, and harassment-free community.

Examples of expected behavior:
- Be respectful and constructive.
- Welcome beginners and different viewpoints.
- Give feedback about ideas and code, not personal characteristics.
- Accept responsibility and correct mistakes.

Unacceptable behavior includes harassment, insults, discrimination, doxxing, and sustained disruptive conduct.

Project maintainers may remove content or restrict participation when necessary to protect the community. Report concerns privately to the repository maintainer.
