# Dev Toolkit — Practical Resources for Coders

A small, language-friendly collection of checklists, templates, command references, and starter snippets that help developers work faster and ship cleaner code.

> Beginner-friendly. Open source. Contributions welcome.

## What's inside

- **Git & GitHub cheat sheet** — everyday commands and safe workflows.
- **Debugging checklist** — a repeatable way to isolate bugs.
- **Code review checklist** — quality, readability, tests, and security.
- **API checklist** — practical checks before releasing an API.
- **Issue and pull request templates** — make collaboration clearer.
- **Starter snippets** — small Python and JavaScript examples.

## Quick start

1. Download or clone this repository.
2. Open the guide or template you need.
3. Copy the relevant checklist/snippet into your own project.
4. Adapt it to your language, framework, and team's conventions.

```bash
git clone https://github.com/YOUR-USERNAME/dev-toolkit.git
cd dev-toolkit
```

## Repository map

```text
dev-toolkit/
├── docs/
│   ├── api-checklist.md
│   ├── code-review-checklist.md
│   ├── debugging-checklist.md
│   └── git-github-cheatsheet.md
├── snippets/
│   ├── javascript/
│   │   └── fetch-json.js
│   └── python/
│       └── retry.py
├── .github/
│   ├── ISSUE_TEMPLATE/
│   │   ├── bug_report.md
│   │   └── feature_request.md
│   └── pull_request_template.md
├── CONTRIBUTING.md
├── CODE_OF_CONDUCT.md
├── SECURITY.md
└── LICENSE
```

## Who is this for?

Students, beginners, solo developers, open-source contributors, and working engineers who want practical references without a lot of noise.

## Contributing

Found a typo? Have a better example? See [CONTRIBUTING.md](CONTRIBUTING.md). Small, focused pull requests are especially welcome.

## License

MIT — see [LICENSE](LICENSE).
