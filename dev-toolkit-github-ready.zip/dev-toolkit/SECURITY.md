# Security Policy

Please do not publish vulnerabilities, credentials, API keys, or private user data in public issues.

To report a security concern, contact the repository owner through the private contact method listed on their GitHub profile. Include:
- A concise description
- Steps to reproduce
- Potential impact
- A suggested fix, if known

Do not test against systems you do not own or have permission to assess.
