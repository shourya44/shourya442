# Git & GitHub Cheat Sheet

## Start a repository

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/USERNAME/REPOSITORY.git
git push -u origin main
```

## Everyday workflow

```bash
git status
git pull
git switch -c feature/short-description
git add path/to/file
git commit -m "Add short description"
git push -u origin feature/short-description
```

Then open a pull request on GitHub.

## Inspect changes

```bash
git diff
git diff --staged
git log --oneline --graph --decorate -10
git show --stat
```

## Undo carefully

```bash
git restore path/to/file       # discard unstaged edits to one file
git restore --staged path      # unstage a file, keep its edits
git revert COMMIT_SHA          # create a new commit that reverses a commit
```

Avoid `git reset --hard` unless you understand that it permanently discards local changes.

## Good commit messages

Prefer short, action-oriented messages:

- `Add password reset validation`
- `Fix empty response handling`
- `Update installation instructions`

## Useful habits

- Pull before starting work.
- Use a branch for each focused change.
- Keep commits small and descriptive.
- Never commit passwords, API keys, private keys, or `.env` files.
- Review `git diff` before committing.
