# Code Review Checklist

## Correctness
- Does the change solve the stated problem?
- Are edge cases and failure paths handled?
- Are assumptions explicit?

## Readability and maintenance
- Are names clear and consistent?
- Is the code simpler than the problem requires?
- Is logic duplicated unnecessarily?
- Are comments explaining why, rather than repeating what?

## Tests
- Are important success and failure cases covered?
- Do tests fail when the bug is reintroduced?
- Are tests deterministic?

## Security and privacy
- Are secrets excluded?
- Is untrusted input validated?
- Are permissions and access checks enforced?
- Are logs free of passwords, tokens, and sensitive data?

## Delivery
- Are docs/configuration updated?
- Are breaking changes called out?
- Can the change be rolled back safely?
