# API Release Checklist

- [ ] Use consistent resource names and HTTP methods.
- [ ] Validate request parameters and payloads on the server.
- [ ] Return appropriate HTTP status codes.
- [ ] Keep error responses predictable and avoid leaking internals.
- [ ] Authenticate callers and authorize each protected action.
- [ ] Apply rate limits where abuse or high load is possible.
- [ ] Set request timeouts and sensible payload-size limits.
- [ ] Paginate potentially large collections.
- [ ] Version breaking changes and document compatibility.
- [ ] Add tests for success, validation, authorization, and failure cases.
- [ ] Log useful request context without logging secrets or sensitive data.
- [ ] Publish examples and clear setup instructions.
