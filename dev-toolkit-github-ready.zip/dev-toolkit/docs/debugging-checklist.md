# Debugging Checklist

Use this sequence instead of changing several things at once.

1. **Reproduce it** — write down the exact steps and expected vs actual result.
2. **Capture evidence** — error message, stack trace, logs, input, environment, and timestamp.
3. **Find the boundary** — identify the first point where actual behavior differs from expected behavior.
4. **Form one hypothesis** — state what you think is wrong and why.
5. **Test the hypothesis** — make the smallest experiment possible.
6. **Check recent changes** — inspect the diff, dependency updates, configuration, and environment.
7. **Fix the cause** — avoid hiding the symptom with a broad workaround.
8. **Add a regression test** — prove the bug stays fixed.
9. **Verify nearby behavior** — run relevant tests and a manual smoke test.
10. **Document the lesson** — record the root cause if it could help the team.

## Bug report essentials

- Short title
- Steps to reproduce
- Expected result
- Actual result
- Error/log output (remove secrets and personal data)
- Environment and version
- Frequency: always, sometimes, or once
