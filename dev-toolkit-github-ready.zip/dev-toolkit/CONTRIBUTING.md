# Contributing

Thanks for helping improve Dev Toolkit!

## Before you contribute

- Search existing issues and pull requests to avoid duplicate work.
- Keep changes focused and beginner-friendly.
- Use clear filenames and headings.
- Do not add secrets, private data, or copyrighted material you do not have permission to share.

## Pull request process

1. Fork the repository.
2. Create a branch: `git switch -c docs/add-topic`.
3. Make and test your change.
4. Check spelling, links, and code formatting.
5. Open a pull request explaining the problem and the solution.

For code snippets, include a short usage example and note important limitations.
