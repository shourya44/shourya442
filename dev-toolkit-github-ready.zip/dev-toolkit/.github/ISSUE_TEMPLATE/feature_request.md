---
name: Feature request
about: Suggest a guide, checklist, or snippet
title: "[Feature]: "
labels: enhancement
---

## What should be added?

## Who would it help?

## Example use case

## References (optional)
