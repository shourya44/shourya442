---
name: Bug report
about: Report a problem in a guide or code snippet
title: "[Bug]: "
labels: bug
---

## What is wrong?

## Steps to reproduce

## Expected result

## Actual result

## Environment / versions

## Logs (remove secrets and personal data)
