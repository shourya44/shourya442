"""Minimal retry helper for transient failures.

Use only for operations that are safe to retry (or are idempotent).
"""
import time
from typing import Callable, TypeVar

T = TypeVar("T")


def retry(operation: Callable[[], T], attempts: int = 3, delay: float = 0.5) -> T:
    if attempts < 1:
        raise ValueError("attempts must be at least 1")
    if delay < 0:
        raise ValueError("delay cannot be negative")

    last_error = None
    for attempt in range(attempts):
        try:
            return operation()
        except (TimeoutError, ConnectionError) as error:
            last_error = error
            if attempt < attempts - 1:
                time.sleep(delay * (2 ** attempt))

    raise last_error


if __name__ == "__main__":
    # Demo only: replace with a real idempotent operation.
    print(retry(lambda: "Connected"))
