/**
 * Fetch JSON with basic HTTP and network error handling.
 * Works in modern browsers and Node.js versions with global fetch.
 */
export async function fetchJson(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: {
      Accept: "application/json",
      ...options.headers,
    },
  });

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
  }

  return response.json();
}

// Example:
// const user = await fetchJson("https://api.example.com/users/1");
